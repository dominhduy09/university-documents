public class MyClass {
    public static void main(String[] args) {
        int myArray[] = new int[7];

        try {
            System.out.println(myArray[9]);

        } catch (ArrayIndexOutOfBoundsException e) {
            // TODO: handle exception
            System.out.println("The element 9 does not exist!");

        }
    }
}