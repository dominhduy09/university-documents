
initial_height = 100;
initial_velocity = 20;
time_hit_ground = objhitground (initial_height , initial_velocity);
fprintf("Time to hit ground: %d ", time_hit_ground)
